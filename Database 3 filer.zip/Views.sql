use EV_Network;

create view `Station Location` as 
select `Charging Station`.`CS ID`, `Operator`.`Operator Name`, `Charging Station`.`Loc Type`, `Charging Station`.`Loc Latitude`, `Charging Station`.`Loc Longitude`, `Charging Station`.`Availability`
from `Charging Station`
inner join `Operator` on `Charging Station`.`Operator ID`=`Operator`.`Operator ID`;


create view `Station Price` as
select `Charging Station`.`CS ID`,`Operator`.`Operator Name` ,`Charging Station`.`Pris`
from `Charging Station`
inner join `Operator` on `Charging Station`.`Operator ID`=`Operator`.`Operator ID`;


create view `Charger Types` as
select `Charging Station`.`CS ID`, `Charging Station`.`Type 2 -43 kW AC`,`Charging Station`.`CHAdeMO - 50 kW DC`,`Charging Station`.`CCS - 50-350 kW DC`,`Charging Station`.`Tesla Type 2 - 150 kW DC`,`Charging Station`.`Type 2 - 7-22 kW AC`,
`Charging Station`.`Type 1 - 7 kW AC`,`Charging Station`.`Commando - 7-22kW AC`,`Charging Station`.`3-pin - 3kW AC`,`Charging Station`.`Type 1 - 3-6kW AC`,`Charging Station`.`Type 2 -3-6 kW AC`,`Charging Station`.`Commando - 3-6 kW AC`
from `Charging Station`
