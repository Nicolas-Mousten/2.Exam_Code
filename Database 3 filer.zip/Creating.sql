create database if not exists EV_Network;

use EV_Network;

create table if not exists `User`(
`User ID` Int primary key auto_increment,
`First Name` Varchar(255),
`Last Name` Varchar(255),
`Email` Varchar(255)
);

create table if not exists `Operator`(
`Operator ID` int primary key,
`Operator Name` varchar(255)
);

#create table if not exists `EV Charger`( 
#`Charger ID2` int primary key auto_increment,
#`Types` varchar(255)
#);

create table if not exists `Charging Station`(
`CS ID` int primary key auto_increment,
`Amenity` VarChar(255),
`Capacity` int,
`Operator ID` Int,
`Loc Type` VarChar(255),
`Loc Latitude` float(12,10) ZEROFILL,
`Loc Longitude` float(12,10) ZEROFILL,
`Pris` float,
`Availability` VarChar(255),
`Type 2 -43 kW AC` INT,
`CHAdeMO - 50 kW DC` INT,
`CCS - 50-350 kW DC` INT,
`Tesla Type 2 - 150 kW DC` INT,
`Type 2 - 7-22 kW AC` int,
`Type 1 - 7 kW AC` int,
`Commando - 7-22kW AC` INT,
`3-pin - 3kW AC` INT,
`Type 1 - 3-6kW AC` int,
`Type 2 -3-6 kW AC` int,
`Commando - 3-6 kW AC` INT,
foreign key(`Operator ID`) references `Operator`(`Operator ID`)
);

create table if not exists `History User`( #Måde at spare informationen fra python koden.
`Date and Time` varchar(255),
`CS ID` Int,
`User ID` int,
`KWH` int,
foreign key(`User ID`) references `User`(`User ID`),
foreign key(`CS ID`) references `Charging Station`(`CS ID`)
);
