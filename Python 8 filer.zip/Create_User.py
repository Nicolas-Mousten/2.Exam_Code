#Nicolas, Marcus, Christian, John, Oliver, 6 juni

#This file is used to make a user for the app, where information like charging history can be saved for later use. it is also the way user can log in to the app 
#and continue to add more info to their charging history or se their consumption other days.


import SqlConnector as database
from beautifultable import BeautifulTable

database.conn()

def User(Name,LastName,Email): #Varables from main menu gets sent to this function.
    mycursor = database.mydb.cursor()
    SQL = "INSERT INTO `User`(`First Name`, `Last Name`, `Email`) values(%s,%s,%s)" #Specify what queries should be executed, inside values you must have %s for every column.

    val = (Name, LastName, Email)   #Here the data is inputtet

    mycursor.execute(SQL, val)  #Here it is executed

    database.mydb.commit()  #When you want to edit a database you must commit your changes 


    mycursor.execute('SELECT * FROM ev_network.user')
    
    myresult = mycursor.fetchall()
    prettyprint(myresult)


def prettyprint(result):
    names = ["ID",'Name','Last Name','Email']
    table = BeautifulTable(maxwidth=140)
    table.column_headers = names
    for row in result:
        table.append_row(row)
    print(table)

def login(LoginInfo):
    global Active_Login
    global UserData
    mycursor = database.mydb.cursor()
    mycursor.execute("Select * from `User` where `User ID` = " + LoginInfo)
    UserData = mycursor.fetchone() #Whitdraws the first row in the column
    print(UserData)
    if UserData == None:
        print("That ID dosen't exists in this database.")
    else:
        Active_Login = LoginInfo
        pass

