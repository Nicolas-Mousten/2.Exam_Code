#Nicolas, Marcus, Christian, John, Oliver, 6 juni

#Main Menu python file is used by the user to orentate though the program. It works by importing the fuctions from other pytohn files 
#and then calling them though an while loop with a bunch of if,elif,else statements.
#In the functions where it calls from other files it also can send information inside the paranteses, it does that to give the answer that the
#user gives to the function and then use it inside the functions. An example of this in this code is the LoginInfo variable that has the users ID and can then perform 
#a search though the database for relevent information inside the PersonalConsumption file.


from logging import exception
import Show_Stations    #Imports other python files
import Show_Price
import Create_User
import ChargerTypes
import ChargingProgress
import PersonalConsumption
global Active_Login
Createaccountstop = True
MainMenuStop = True
while Createaccountstop == True:
    Createaccountstop = True
    MainMenuStop = True
    try:
        print("Create Account=1, Log in on account=2")
        choiceaccount = int(input(">"))
        if choiceaccount == 1:
            Name = str(input('Name: \n'))
            LastName = str(input('Last Name: \n'))
            Email = str(input('Email: \n'))
            Create_User.User(Name,LastName,Email)       #Calls on a python files function and send the variables Name, LastName, Email to it.

        elif choiceaccount == 2:
            LoginInfo = str(input("ID:"))
            Create_User.login(LoginInfo)    #Calls on a python file and sends the variable LoginInfo to it.

            if Create_User.UserData == None:
                break
            print("Logging In")
            while MainMenuStop == True:
                try:
                    print("1=Show all station locations, 2=Show station prices , 3=Show types of chargers at each station, 4=Charging Progress, 5=Show Charging history, 6=Quit")
                    choice1 = int(input('>'))
                    if choice1 == 1:
                        Show_Stations.show_table()
                    elif choice1 == 2:
                        Show_Price.show_Price()
                    elif choice1 == 3:
                        ChargerTypes.ChargerTypes()
                    elif choice1 == 4:
                        ChargingProgress.TimeC()
                    elif choice1 == 5:
                        PersonalConsumption.Show_Consumption(LoginInfo)
                    elif choice1 == 6:
                        MainMenuStop = False
                        Createaccountstop = False
                    else:
                        print('Try again')
                except Exception:
                    print("Try again")
    except Exception:
        print("Try again")











