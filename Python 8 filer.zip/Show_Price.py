#Nicolas, Marcus, Christian, John, Oliver, 6 juni

#This file shows the stations price. It is done with a view from the database and then shown in a grid with beutifultable.

import SqlConnector as database
from beautifultable import BeautifulTable

database.conn()


def show_Price():
    mycursor = database.mydb.cursor()


    mycursor.execute("SELECT * FROM ev_network.`station price`")

    myresult = mycursor.fetchall()
    prettyprint(myresult)

def prettyprint(result):
    names = ["CS ID",'Operator Name','Price']
    table = BeautifulTable(maxwidth=140, precision=10)
    table.column_headers = names
    for row in result:
        table.append_row(row)
    print(table)

