#Nicolas, Marcus, Christian, John, Oliver, 6 juni

#This File is used to show a view from the database with help from the file SqlConnector. It makes it possible to whitdraw the view and show it in the import BeutifulTable
#To use variables from other files you need to specify where the variable is from. Like for mydb that is from SqlConnector where the kode is written like database.mydb.cursor().

import SqlConnector as database #Imports the database from another python file.
from beautifultable import BeautifulTable   #Imports module for creating grids.


database.conn()

def show_table():
    mycursor = database.mydb.cursor()   #Makes a variable mycursor that makes it possible to run command queris from MySQL in python


    mycursor.execute("SELECT * FROM ev_network.`station location`") #Runs the queris in the execute field.

    myresult = mycursor.fetchall()  #Fetches all the information from the execute field
    prettyprint(myresult)   #Send the data to function Prettyprint for gridding.


def prettyprint(result):
    names = ["CS ID",'Operator Name','Loc_Type','Loc_Latitude','Loc_Longitude','Availability'] #Names of the headers in the grid.
    table = BeautifulTable(maxwidth=140, precision=10)  #Calls the module and specify width and number of decimals in the grid.
    table.column_headers = names    #Submits the names for the headers from earlier
    for row in result:
        table.append_row(row)   #appends the grid in the right order
    print(table)    #Prints the grid


