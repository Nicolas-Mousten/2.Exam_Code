#Nicolas, Marcus, Christian, John, Oliver, 6 juni


#This file is the connection to the database that makes it possible to whitdraw information from the database and submit new information.

import mysql.connector # imports connector module to MySQL database
def conn():
    global mydb #Makes the variable global insted of local
    mydb = mysql.connector.connect(         #Log in to the database
        host='localhost',   
        user='root',
        password='Uvnx3gxc',
        database='EV_Network'
    )

    return mydb #outputs the database data to other files that imports this file

