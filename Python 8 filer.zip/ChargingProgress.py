#Nicolas, Marcus, Christian, John, Oliver, 6 juni


#This file is where the code takes the users input and sends it to the file PersonalConsumption to the function history where it adds it to the database memory and thereafter 
#continue to where the user can choose how much battery their car has and then the program wil calculate how much it needs to charge to reach 100KW 
#Thereafter you choose a charger that has a maximum capacity and then the program calculates how many hours it takes to fully charge the car.
#Thereafter it shows a progress bar that shows in numbers symbolising the charge in the car how far along the car is to beign finished. And then at certain interwals
#the user gets status updates that says, 25% done, 50% done, 75% done. That can easily be modified to send a message to the real phone since this is a prototype.

import time
import PersonalConsumption
import SqlConnector as database

def TimeC():
    
    PreCharge=int(input("Percentage charged:"))
    NeedCharge = 100 - PreCharge 
    PersonalConsumption.history(NeedCharge)
    print("")
    print("You need to charge:",NeedCharge)
    print("")
    print("1='Type 2 -43 kW AC', 2='CHAdeMO - 50 kW DC', 3='CCS - 50-350 kW DC', 4='Tesla Type 2 - 150 kW DC', 5='Type 2 - 7-22 kW AC', 6='Type 1 - 7 kW AC',")
    print(" 7='Commando - 7-22kW AC', 8='3-pin - 3kW AC', 9='Type 1 - 3-6kW AC', 10='Type 2 -3-6 kW AC', 11='Commando - 3-6 kW AC'")
    ChargerType=int(input("Type of charger:"))

    if ChargerType == 1:
        ChargerTypeSpeed = 43
    elif ChargerType ==2:
        ChargerTypeSpeed = 50
    elif ChargerType ==3:
        ChargerTypeSpeed = 120
    elif ChargerType ==4:
        ChargerTypeSpeed = 150
    elif ChargerType ==5:
        ChargerTypeSpeed = 22
    elif ChargerType ==6:
        ChargerTypeSpeed = 7
    elif ChargerType ==7:
        ChargerTypeSpeed = 22
    elif ChargerType ==8:
        ChargerTypeSpeed = 3
    elif ChargerType ==9:
        ChargerTypeSpeed = 6
    elif ChargerType ==10:    
        ChargerTypeSpeed = 6
    elif ChargerType ==11:
        ChargerTypeSpeed = 6
    

    TimeToCharge = round(NeedCharge/ChargerTypeSpeed, 2) #Calculates the amount of charge that the car needs to charge to reach 100.

    print("It will take" , TimeToCharge , "hours to charge your car.")
    Timer(PreCharge, NeedCharge)#Sends the info to status calculations

def Timer(x, y):
    #x = int(input())
    #y = int(input())
    quarter_there = int(((y)/4)+x)#25% 
    halfway_there = int(((y)/2)+x)#50%
    Quarter_left = int(((3/4)*(y))+x)#75%
    #print(quarter_there,"25")
    #print(halfway_there,"50")
    #print(Quarter_left,"75")
    y = x+y
    x=x-1   #-1 on x to make it start on the number given instead of one above.
    print("----------------")
    while x != y:
        x += 1 #Adds one to x for each time it goes though the loop.
        if (x == halfway_there):
            print(halfway_there,"50% Done")
        elif (x == quarter_there):
            print(quarter_there,"25% Done")
        elif (x == Quarter_left):
            print(Quarter_left,"75% Done")
        else:
            print(x)
        time.sleep(0.1) #Sets a wait time for the code to give a close representation of time 
    print("Finished Charging")