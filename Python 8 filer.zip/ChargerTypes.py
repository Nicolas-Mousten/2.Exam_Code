#Nicolas, Marcus, Christian, John, Oliver, 6 juni


#This file shows the different charger types and how many of them there are at each station. It is done with a view from the database
#and then shown in a grid though beutifultable.

import SqlConnector as database
from beautifultable import BeautifulTable


database.conn()

def ChargerTypes():
    mycursor = database.mydb.cursor()
    mycursor.execute("SELECT * FROM `Charger Types`")
    myresult = mycursor.fetchall()
    prettyprint(myresult)

def prettyprint(result):
    names = ['CS ID','Type 2 -43 kW AC','CHAdeMO - 50 kW DC','CCS - 50-350 kW DC','Tesla Type 2 - 150 kW DC','Type 2 - 7-22 kW AC','Type 1 - 7 kW AC','Commando - 7-22kW AC','3-pin - 3kW AC','Type 1 - 3-6kW AC','Type 2 -3-6 kW AC','Commando - 3-6 kW AC']
    table = BeautifulTable(maxwidth=140)
    table.column_headers = names
    for row in result:
        table.append_row(row)
    print(table)


