#Nicolas, Marcus, Christian, John, Oliver, 6 juni

#This file shows the users consumptions of electricity. It gets the id info from the main menu file and then prints the result with beutiful table.
#it also submits information to the database about the users 


from beautifultable.beautifultable import BeautifulTable
import SqlConnector as database
import Create_User
from datetime import datetime#show date and time
now = datetime.now()#show date and time
current_time = now.strftime("%H:%M:%S")#show date and time 
current_day = now.strftime("%D")#show date and time
database.conn() #Get the database from the file

def history(NeedCharge):
    global DateandTimestr
    global CSID
    DateandTime = (current_day,current_time)    #Saves the date and time
    DateandTimestr = str(DateandTime)   #Remake the date and time into str 
    #-----------Kigger om ID existerer i databasen--------
    print("Input Station ID")
    CSID=(str(input(">")))
    mycursor = database.mydb.cursor()
    mycursor.execute("Select * from `Charging Station` where `CS ID` = " + CSID)    #Search though the database after station ID
    Station_ID = mycursor.fetchone()
    if Station_ID == None:
        print("That ID dosen't exist")
    #----------Fyld informationen ind i databasen---------------
    else:
        InputinfoDatabasetempo(NeedCharge)

def InputinfoDatabasetempo(NeedCharge):
    mycursor = database.mydb.cursor()

    SQL = "INSERT INTO `History User`(`Date and Time`, `CS ID`,`User ID`,`KWH`) values(%s,%s,%s,%s)"
    val = (DateandTimestr,CSID,Create_User.Active_Login,NeedCharge)
    mycursor.execute(SQL, val)
    database.mydb.commit()
    mycursor.execute("Select * From ev_network.`History User`")
    myresult = mycursor.fetchall()
    for x in myresult:
        print(x)



def Show_Consumption(LoginInfo):#Shows the timestamps and id of the station for every time the user has been to a station
    mycursor = database.mydb.cursor()
    mycursor.execute("Select * From ev_network.`History User` where `User ID` =" + LoginInfo)
    myresult = mycursor.fetchall()
    prettyprint(myresult)


def prettyprint(result):
    names = ["Date and Time","CS ID","User ID","KWH"]
    table = BeautifulTable(maxwidth=140)
    table.column_headers = names
    for row in result:
        table.append_row(row)
    print(table)